/* ********************************************************************
*  file: forbidden.h.                            For Forbidden Inn    *
**********************************************************************/

#define FORBIDDEN_ENTRANCE 8835
#define FORBIDDEN_INSIDE   8836
