# Crimson-2-MUD
This is a MUD based on the DikuMUD/CircleMUD Codebase

Update: 19-07-2020
We have determined to use the new License for DikuMUD.


DIRECTORIES
/controlscripts			- This folder contains various scripts used by the MUD

/src				- This folder contains the source code of the MUD

/prod				- This folder contains the files necessary for the production port

/dev				- This folder contains the files necessary for the development port

/hell				- This folder contains the files necessary for the hellninght port.
				This folder does not exist on GITHUB it can be a copy of the production port.
				When copying this do not include the contents of /prod/lib/rentfiles but include the folder structure.
				Do not include the players file.
                       
/test				- This folder should contain the files necessary for a testing port.                       
				This folder does not exist on GITHUB it can be a copy of the production port.
				When copying this do not include the contents of /prod/lib/rentfiles but include the folder structure.
				Do not include the players file.

FILES:
LICENSE				- This is the license used by DIKUMUD.

README				- This is the file you are reading right now
