#!/bin/sh


cp BlankZone.mob $1.mob
cp BlankZone.obj $1.obj
cp BlankZone.wld $1.wld
cp BlankZone.zon $1.zon
