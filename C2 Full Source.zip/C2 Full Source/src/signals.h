/* signals.h */

void signal_setup(void);
void checkpointing(int i);
void terminate_request(int i);
void logsig(int i);
void stop_sig(int i);
void infinate_loop_check(int i);
