/* oa */
/* *******************************************************************
*  file: objact.c , Special opject module.   Part of Crimson MUD     *
*  Usage: Procedures handling object activity                        *
*                     Written by Hercules                            *
******************************************************************** */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>

#include "structs.h"
#include "utility.h"
#include "comm.h"
#include "db.h"
#include "handler.h"
#include "parser.h"
#include "spells.h"
#include "constants.h"
#include "modify.h"
#include "ansi.h"
#include "globals.h"
#include "func.h"

void oa1000_object_activity(void)
{

/*	register struct obj_data *k;

        for (k = object_list; k; k = k->next) {
		if (obj_index[k->item_number].func) {
			sp_obj = k;
			(*obj_index[k->item_number].func) (0, 0, "");
		}
	}
	sp_obj = 0;
*/
	return;
}
